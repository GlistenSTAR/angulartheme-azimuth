import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-basic-tables',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './basic-tables.component.html'
})
export class BasicTablesComponent { }