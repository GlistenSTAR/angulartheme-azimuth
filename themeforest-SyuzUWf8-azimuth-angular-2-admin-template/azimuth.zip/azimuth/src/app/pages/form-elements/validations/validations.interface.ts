export interface MyForm {
    simple: string;
    minLength: string;
    maxLength: string;
    email: string;
    password: string;
    confirmPassword: string;
    website: string;   
}