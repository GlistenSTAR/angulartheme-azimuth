import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-media-objects',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './media-objects.component.html'
})
export class MediaObjectsComponent {  
}
