import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-cards',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './cards.component.html'
})
export class CardsComponent { }
