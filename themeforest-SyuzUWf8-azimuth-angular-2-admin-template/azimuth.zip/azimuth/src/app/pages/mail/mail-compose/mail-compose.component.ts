import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-mail-compose',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './mail-compose.component.html'
})
export class MailComposeComponent { }
