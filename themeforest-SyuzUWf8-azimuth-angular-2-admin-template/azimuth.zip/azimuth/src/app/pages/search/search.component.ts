import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'az-search',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './search.component.html'
})
export class SearchComponent {}